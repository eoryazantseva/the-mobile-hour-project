<nav class="col-md-2 d-none d-md-block bg-light sidebar">
      <div class="sidebar-sticky">
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link" href="index.php">
              <i class="fa-solid fa-gauge"></i>
              Dashboard <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="customer_orders.php">
        <i class="fa-regular fa-note-sticky"></i>
              Orders
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="products.php">
              <i class="fa-solid fa-cart-shopping"></i>
              Products
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="customers.php">
              <i class="fa-solid fa-person"></i>
              Customers
            </a>
          </li>
        </ul>
      </div>
    </nav>
